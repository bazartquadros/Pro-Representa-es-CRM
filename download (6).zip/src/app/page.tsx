import { redirect } from 'next/navigation';

export default function Home() {
  // In a real app, you would check for authentication here
  // and redirect to '/login' if not authenticated.
  // For this demo, we'll redirect directly to the dashboard.
  redirect('/dashboard');
}
