"use client"

import * as React from "react"
import { CaretSortIcon, DotsHorizontalIcon } from "@radix-ui/react-icons"
import { ColumnDef } from "@tanstack/react-table"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu"
import { DataTable } from "@/components/data-table"
import type { Appointment } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { useToast } from "@/hooks/use-toast"
import { AppointmentForm, type AppointmentFormValues } from "@/components/forms/appointment-form"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { getAppointments, addAppointment, updateAppointment, deleteAppointment } from "@/services/appointment-service"
import { Loader2 } from "lucide-react"


export default function AppointmentsPage() {
    const { toast } = useToast()
    const [appointments, setAppointments] = React.useState<Appointment[]>([])
    const [isLoading, setIsLoading] = React.useState(true)
    const [isFormOpen, setIsFormOpen] = React.useState(false)
    const [isCancelDialogOpen, setIsCancelDialogOpen] = React.useState(false)
    const [selectedAppointment, setSelectedAppointment] = React.useState<Appointment | null>(null)

     React.useEffect(() => {
        const fetchAppointments = async () => {
            try {
                const appointmentsData = await getAppointments();
                setAppointments(appointmentsData);
            } catch (error) {
                toast({
                    variant: "destructive",
                    title: "Erro ao buscar compromissos",
                    description: "Não foi possível carregar a lista de compromissos.",
                });
            } finally {
                setIsLoading(false);
            }
        };
        fetchAppointments();
    }, [toast]);


    const handleAdd = () => {
        setSelectedAppointment(null)
        setIsFormOpen(true)
    }

    const handleReagenda = (appointment: Appointment) => {
        setSelectedAppointment(appointment)
        setIsFormOpen(true)
    }

    const handleCancel = (appointment: Appointment) => {
        setSelectedAppointment(appointment)
        setIsCancelDialogOpen(true)
    }

    const confirmCancel = async () => {
        if (!selectedAppointment) return;
        try {
            await updateAppointment(selectedAppointment.id, { status: 'Cancelado' })
            setAppointments(appointments.map(a => a.id === selectedAppointment.id ? { ...a, status: 'Cancelado' } : a));
            toast({ title: "Compromisso cancelado", description: `O compromisso "${selectedAppointment.title}" foi cancelado.` })
        } catch (error) {
            toast({ variant: "destructive", title: "Erro", description: "Não foi possível cancelar o compromisso." })
        } finally {
            setIsCancelDialogOpen(false)
            setSelectedAppointment(null)
        }
    }

    const handleStatusChange = async (appointmentToUpdate: Appointment, newStatus: Appointment['status']) => {
        try {
            await updateAppointment(appointmentToUpdate.id, { status: newStatus });
            setAppointments(appointments.map(a => a.id === appointmentToUpdate.id ? { ...a, status: newStatus } : a));
            toast({
                title: "Status do Compromisso Atualizado",
                description: `O status de "${appointmentToUpdate.title}" foi alterado para "${newStatus}".`
            })
        } catch (error) {
             toast({ variant: "destructive", title: "Erro", description: "Não foi possível atualizar o status." })
        }
    }

    const handleFormSubmit = async (values: AppointmentFormValues) => {
        try {
            if (selectedAppointment) {
                // Update
                const appointmentData = { ...values, dateTime: values.dateTime.toISOString() };
                await updateAppointment(selectedAppointment.id, appointmentData)
                setAppointments(appointments.map(a => a.id === selectedAppointment.id ? { ...selectedAppointment, ...appointmentData } : a))
                toast({ title: "Compromisso atualizado", description: "Os dados do compromisso foram atualizados." })
            } else {
                // Create
                const newAppointment = await addAppointment(values);
                setAppointments([newAppointment, ...appointments])
                toast({ title: "Compromisso adicionado", description: "O novo compromisso foi agendado." })
            }
            setIsFormOpen(false)
            setSelectedAppointment(null)
        } catch (error) {
            toast({ variant: "destructive", title: "Erro ao salvar", description: "Não foi possível salvar o compromisso." })
        }
    }

    const columns: ColumnDef<Appointment>[] = [
        {
            id: "select",
            header: ({ table }) => (
            <Checkbox
                checked={table.getIsAllPageRowsSelected()}
                onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
                aria-label="Selecionar tudo"
            />
            ),
            cell: ({ row }) => (
            <Checkbox
                checked={row.getIsSelected()}
                onCheckedChange={(value) => row.toggleSelected(!!value)}
                aria-label="Selecionar linha"
            />
            ),
        },
        {
            accessorKey: "title",
            header: "Título",
        },
        {
            accessorKey: "customerName",
            header: "Cliente",
        },
        {
            accessorKey: "dateTime",
            header: ({ column }) => (
            <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}>
                Data e Hora
                <CaretSortIcon className="ml-2 h-4 w-4" />
            </Button>
            ),
            cell: ({ row }) => {
                const date = new Date(row.getValue("dateTime"));
                return <div>{format(date, "PPP p", { locale: ptBR })}</div>;
            },
        },
        {
            accessorKey: "status",
            header: "Status",
            cell: ({ row }) => {
                const status = row.getValue("status") as string;
                const variant = status === 'Realizado' ? 'default' : status === 'Agendado' ? 'secondary' : 'destructive';
                const className = status === 'Realizado' ? 'bg-accent text-accent-foreground' : '';
                return <Badge variant={variant} className={className}>{status}</Badge>
            }
        },
        {
            accessorKey: "representativeName",
            header: "Representante",
        },
        {
            id: "actions",
            cell: ({ row }) => {
                const appointment = row.original
                return (
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Abrir menu</span>
                            <DotsHorizontalIcon className="h-4 w-4" />
                        </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Ações</DropdownMenuLabel>
                        <DropdownMenuItem 
                            onClick={() => handleStatusChange(appointment, 'Realizado')}
                            disabled={appointment.status === 'Realizado' || appointment.status === 'Cancelado'}
                        >
                            Marcar como Realizado
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                            onClick={() => handleReagenda(appointment)}
                            disabled={appointment.status === 'Cancelado'}
                        >
                            Reagendar
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                            className="text-destructive" 
                            onClick={() => handleCancel(appointment)}
                            disabled={appointment.status === 'Cancelado'}
                        >
                            Cancelar
                        </DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                )
            }
        },
    ]

    return (
        <>
            <AppointmentForm 
                isOpen={isFormOpen}
                onOpenChange={setIsFormOpen}
                onSubmit={handleFormSubmit}
                defaultValues={selectedAppointment}
            />
            <AlertDialog open={isCancelDialogOpen} onOpenChange={setIsCancelDialogOpen}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Você tem certeza?</AlertDialogTitle>
                        <AlertDialogDescription>
                            Essa ação não pode ser desfeita. Isso cancelará o compromisso <span className="font-semibold">"{selectedAppointment?.title}"</span>.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Voltar</AlertDialogCancel>
                        <AlertDialogAction onClick={confirmCancel} className="bg-destructive hover:bg-destructive/90">Sim, Cancelar</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>

            <div className="flex flex-col gap-6">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight font-headline">Compromissos</h1>
                        <p className="text-muted-foreground">
                            Acompanhe suas reuniões e agenda.
                        </p>
                    </div>
                    <Button onClick={handleAdd}>Novo Compromisso</Button>
                </div>
                 {isLoading ? (
                    <div className="flex items-center justify-center p-8">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                         <p className="ml-4">Carregando compromissos...</p>
                    </div>
                ) : (
                    <DataTable 
                        columns={columns} 
                        data={appointments}
                        filterColumnId="title"
                        filterPlaceholder="Filtrar por título..."
                    />
                )}
            </div>
        </>
    )
}
