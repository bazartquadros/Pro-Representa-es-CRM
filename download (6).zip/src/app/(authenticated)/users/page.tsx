"use client"

import * as React from "react"
import { CaretSortIcon, DotsHorizontalIcon } from "@radix-ui/react-icons"
import { ColumnDef } from "@tanstack/react-table"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuSub, DropdownMenuSubTrigger, DropdownMenuPortal, DropdownMenuSubContent, DropdownMenuRadioGroup, DropdownMenuRadioItem } from "@/components/ui/dropdown-menu"
import { DataTable } from "@/components/data-table"
import type { User } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { UserForm, UserFormValues } from "@/components/forms/user-form"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { User as UserIcon, Loader2 } from "lucide-react"
import { getUsers, addUser, updateUser, deleteUser } from "@/services/user-service"

const useUserRole = () => ({ role: 'admin' });

const userRoles: User['role'][] = ['admin', 'representative'];

export default function UsersPage() {
    const { role } = useUserRole();
    const { toast } = useToast()
    const [users, setUsers] = React.useState<User[]>([])
    const [isLoading, setIsLoading] = React.useState(true)
    const [isFormOpen, setIsFormOpen] = React.useState(false)
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = React.useState(false)
    const [selectedUser, setSelectedUser] = React.useState<User | null>(null)

    React.useEffect(() => {
        const fetchUsers = async () => {
            try {
                const usersData = await getUsers();
                setUsers(usersData);
            } catch (error) {
                 toast({
                    variant: "destructive",
                    title: "Erro ao buscar usuários",
                    description: "Não foi possível carregar a lista de usuários.",
                });
            } finally {
                setIsLoading(false);
            }
        };
        if (role === 'admin') {
            fetchUsers();
        }
    }, [toast, role]);


    const handleAdd = () => {
        setSelectedUser(null)
        setIsFormOpen(true)
    }

    const handleEdit = (user: User) => {
        setSelectedUser(user)
        setIsFormOpen(true)
    }

    const handleDelete = (user: User) => {
        setSelectedUser(user)
        setIsDeleteDialogOpen(true)
    }

    const confirmDelete = async () => {
        if (!selectedUser) return;
        try {
            await deleteUser(selectedUser.id);
            setUsers(users.filter(u => u.id !== selectedUser.id))
            toast({ title: "Usuário excluído", description: `O usuário "${selectedUser.name}" foi excluído com sucesso.` })
        } catch (error) {
             toast({
                variant: "destructive",
                title: "Erro ao excluir",
                description: "Não foi possível excluir o usuário.",
            });
        } finally {
            setIsDeleteDialogOpen(false)
            setSelectedUser(null)
        }
    }

    const handleRoleChange = async (userToUpdate: User, newRole: User['role']) => {
        try {
            await updateUser(userToUpdate.id, { role: newRole });
            setUsers(users.map(u => u.id === userToUpdate.id ? { ...u, role: newRole } : u));
            toast({
                title: "Função do Usuário Atualizada",
                description: `A função de ${userToUpdate.name} foi alterada para "${newRole}".`
            })
        } catch (error) {
             toast({
                variant: "destructive",
                title: "Erro ao alterar função",
                description: "Não foi possível alterar a função do usuário.",
            });
        }
    }

    const handleFormSubmit = async (values: UserFormValues) => {
        try {
            if (selectedUser) {
                // Update
                await updateUser(selectedUser.id, values);
                setUsers(users.map(u => u.id === selectedUser.id ? { ...u, ...values } : u))
                toast({ title: "Usuário atualizado", description: "Os dados do usuário foram atualizados." })
            } else {
                // Create
                const newUser = await addUser(values);
                setUsers([newUser, ...users])
                toast({ title: "Usuário adicionado", description: "O novo usuário foi adicionado." })
            }
            setIsFormOpen(false)
            setSelectedUser(null)
        } catch (error) {
             toast({
                variant: "destructive",
                title: "Erro ao salvar",
                description: "Não foi possível salvar os dados do usuário.",
            });
        }
    }


    if (role !== 'admin') {
        return (
            <div className="flex items-center justify-center h-[calc(100vh-10rem)]">
                <div className="text-center">
                    <h1 className="text-2xl font-bold tracking-tight">Acesso Negado</h1>
                    <p className="text-muted-foreground">Você não tem permissão para acessar esta página.</p>
                </div>
            </div>
        )
    }

    const columns: ColumnDef<User>[] = [
      {
        id: "select",
        header: ({ table }) => (
          <Checkbox
            checked={table.getIsAllPageRowsSelected()}
            onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
            aria-label="Selecionar tudo"
          />
        ),
        cell: ({ row }) => (
          <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => row.toggleSelected(!!value)}
            aria-label="Selecionar linha"
          />
        ),
      },
      {
        accessorKey: "name",
        header: ({ column }) => (
          <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}>
            Nome
            <CaretSortIcon className="ml-2 h-4 w-4" />
          </Button>
        ),
        cell: ({ row }) => (
            <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted text-muted-foreground">
                    <UserIcon className="h-4 w-4" />
                </div>
                <span>{row.getValue("name")}</span>
            </div>
        )
      },
      {
        accessorKey: "email",
        header: "Email",
      },
      {
        accessorKey: "role",
        header: "Função",
        cell: ({ row }) => (
          <Badge variant={row.getValue("role") === 'admin' ? 'default' : 'secondary'}>
            {row.getValue("role") === 'admin' ? 'Admin' : 'Representante'}
          </Badge>
        ),
      },
      {
        id: "actions",
        cell: ({ row }) => {
            const user = row.original
            return (
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="h-8 w-8 p-0">
                        <span className="sr-only">Abrir menu</span>
                        <DotsHorizontalIcon className="h-4 w-4" />
                    </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Ações</DropdownMenuLabel>
                    <DropdownMenuItem onClick={() => handleEdit(user)}>Editar Usuário</DropdownMenuItem>
                     <DropdownMenuSub>
                        <DropdownMenuSubTrigger>Alterar Função</DropdownMenuSubTrigger>
                        <DropdownMenuPortal>
                            <DropdownMenuSubContent>
                                <DropdownMenuRadioGroup value={user.role} onValueChange={(newRole) => handleRoleChange(user, newRole as User['role'])}>
                                {userRoles.map((role) => (
                                    <DropdownMenuRadioItem key={role} value={role}>{role === 'admin' ? 'Admin' : 'Representante'}</DropdownMenuRadioItem>
                                ))}
                                </DropdownMenuRadioGroup>
                            </DropdownMenuSubContent>
                        </DropdownMenuPortal>
                    </DropdownMenuSub>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="text-destructive" onClick={() => handleDelete(user)}>Excluir Usuário</DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>
            )
        },
      },
    ]

    return (
        <>
            <UserForm
                isOpen={isFormOpen}
                onOpenChange={setIsFormOpen}
                onSubmit={handleFormSubmit}
                defaultValues={selectedUser}
            />
            <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Você tem certeza?</AlertDialogTitle>
                        <AlertDialogDescription>
                            Essa ação não pode ser desfeita. Isso excluirá permanentemente o usuário <span className="font-semibold">"{selectedUser?.name}"</span>.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                        <AlertDialogAction onClick={confirmDelete} className="bg-destructive hover:bg-destructive/90">Excluir</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>

            <div className="flex flex-col gap-6">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight font-headline">Gerenciamento de Usuários</h1>
                        <p className="text-muted-foreground">
                            Crie e gerencie contas e funções de usuários.
                        </p>
                    </div>
                    <Button onClick={handleAdd}>Adicionar Usuário</Button>
                </div>
                 {isLoading ? (
                    <div className="flex items-center justify-center p-8">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                         <p className="ml-4">Carregando usuários...</p>
                    </div>
                ) : (
                    <DataTable 
                        columns={columns} 
                        data={users}
                        filterColumnId="name"
                        filterPlaceholder="Filtrar por nome..."
                    />
                )}
            </div>
        </>
    )
}
