"use client"

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarIcon, Download } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import React from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DateRange } from "react-day-picker";
import { getSales } from "@/services/sales-service";
import { getUsers } from "@/services/user-service";
import type { Sale, User } from "@/lib/types";

export default function ReportsPage() {
    const [date, setDate] = React.useState<DateRange | undefined>({
        from: new Date(new Date().setFullYear(new Date().getFullYear() -1)),
        to: new Date(),
    });
    const [sales, setSales] = React.useState<Sale[]>([]);
    const [users, setUsers] = React.useState<User[]>([]);
    const [filteredSales, setFilteredSales] = React.useState<Sale[]>([]);
    const [selectedRep, setSelectedRep] = React.useState<string>("all");

    React.useEffect(() => {
        async function fetchData() {
            const [salesData, usersData] = await Promise.all([
                getSales(),
                getUsers()
            ]);
            setSales(salesData);
            setFilteredSales(salesData);
            setUsers(usersData.filter(u => u.role === 'representative'));
        }
        fetchData();
    }, []);

    const handleGenerateReport = () => {
        let filtered = sales;

        if (selectedRep !== "all") {
            filtered = filtered.filter(sale => sale.representativeName === selectedRep);
        }

        if (date?.from && date?.to) {
            filtered = filtered.filter(sale => {
                const saleDate = typeof sale.date === 'string' ? new Date(sale.date) : new Date((sale.date as any).seconds * 1000);
                return saleDate >= date.from! && saleDate <= date.to!;
            });
        }
        
        setFilteredSales(filtered);
    };

    const handleDownloadCsv = () => {
        const headers = ["Cliente", "Produto", "Representante", "Data", "Valor"];
        const csvRows = [
            headers.join(','),
            ...filteredSales.map(sale => {
                const saleDate = typeof sale.date === 'string' ? new Date(sale.date) : new Date((sale.date as any).seconds * 1000);
                const row = [
                    sale.customerName,
                    sale.product,
                    sale.representativeName,
                    saleDate.toLocaleDateString('pt-BR'),
                    sale.amount
                ];
                return row.join(',');
            })
        ];

        const csvString = csvRows.join('\n');
        const blob = new Blob([csvString], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.setAttribute('hidden', '');
        a.setAttribute('href', url);
        a.setAttribute('download', 'relatorio_vendas.csv');
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    };


    return (
        <div className="flex flex-col gap-6">
             <div>
                <h1 className="text-3xl font-bold tracking-tight font-headline">Relatórios</h1>
                <p className="text-muted-foreground">
                    Gere e visualize relatórios de vendas e cotações.
                </p>
            </div>
            <Card>
                <CardHeader>
                    <CardTitle className="font-headline">Filtros</CardTitle>
                    <CardDescription>Selecione filtros para gerar seu relatório.</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col sm:flex-row gap-4 items-center">
                    <Select onValueChange={setSelectedRep} defaultValue="all">
                        <SelectTrigger className="w-full sm:w-[180px]">
                            <SelectValue placeholder="Selecione um representante" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">Todos os Representantes</SelectItem>
                            {users.map(rep => (
                                <SelectItem key={rep.id} value={rep.name}>{rep.name}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>

                    <Popover>
                        <PopoverTrigger asChild>
                        <Button
                            id="date"
                            variant={"outline"}
                            className={cn(
                            "w-full sm:w-[300px] justify-start text-left font-normal",
                            !date && "text-muted-foreground"
                            )}
                        >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {date?.from ? (
                            date.to ? (
                                <>
                                {format(date.from, "LLL dd, y", { locale: ptBR })} -{" "}
                                {format(date.to, "LLL dd, y", { locale: ptBR })}
                                </>
                            ) : (
                                format(date.from, "LLL dd, y", { locale: ptBR })
                            )
                            ) : (
                            <span>Escolha uma data</span>
                            )}
                        </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                            initialFocus
                            mode="range"
                            defaultMonth={date?.from}
                            selected={date}
                            onSelect={setDate}
                            numberOfMonths={2}
                            locale={ptBR}
                        />
                        </PopoverContent>
                    </Popover>

                    <Button className="w-full sm:w-auto" onClick={handleGenerateReport}>Gerar Relatório</Button>
                    <Button variant="outline" className="w-full sm:w-auto ml-0 sm:ml-auto" onClick={handleDownloadCsv}>
                        <Download className="mr-2 h-4 w-4" />
                        Baixar CSV
                    </Button>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle className="font-headline">Relatório de Vendas</CardTitle>
                    <CardDescription>Vendas do período selecionado.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Cliente</TableHead>
                                <TableHead>Produto</TableHead>
                                <TableHead>Representante</TableHead>
                                <TableHead>Data</TableHead>
                                <TableHead className="text-right">Valor</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {filteredSales.map(sale => (
                                <TableRow key={sale.id}>
                                    <TableCell>{sale.customerName}</TableCell>
                                    <TableCell>{sale.product}</TableCell>
                                    <TableCell>{sale.representativeName}</TableCell>
                                    <TableCell>{new Date(typeof sale.date === 'string' ? sale.date : (sale.date as any).seconds * 1000).toLocaleDateString('pt-BR')}</TableCell>
                                    <TableCell className="text-right">{new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(sale.amount)}</TableCell>
                                </TableRow>
                            ))}
                             {filteredSales.length === 0 && (
                                <TableRow>
                                    <TableCell colSpan={5} className="h-24 text-center">Nenhuma venda encontrada para os filtros selecionados.</TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
}
