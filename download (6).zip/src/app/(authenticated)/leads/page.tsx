"use client"

import * as React from "react"
import { CaretSortIcon, DotsHorizontalIcon } from "@radix-ui/react-icons"
import { ColumnDef } from "@tanstack/react-table"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuSub, DropdownMenuSubTrigger, DropdownMenuSubContent, DropdownMenuRadioGroup, DropdownMenuRadioItem } from "@/components/ui/dropdown-menu"
import { DataTable } from "@/components/data-table"
import type { Lead, Customer } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { LeadForm, type LeadFormValues } from "@/components/forms/lead-form"
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog"
import { getLeads, addLead, updateLead, deleteLead, convertLeadToCustomer } from "@/services/lead-service"
import { Loader2 } from "lucide-react"

const leadStatuses: Lead['status'][] = ['Novo', 'Contatado', 'Qualificado', 'Perdido'];

export default function LeadsPage() {
    const { toast } = useToast()
    const [leads, setLeads] = React.useState<Lead[]>([])
    const [isLoading, setIsLoading] = React.useState(true)
    const [isFormOpen, setIsFormOpen] = React.useState(false)
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = React.useState(false)
    const [selectedLead, setSelectedLead] = React.useState<Lead | null>(null)

    React.useEffect(() => {
        const fetchLeads = async () => {
            try {
                const leadsData = await getLeads();
                setLeads(leadsData);
            } catch (error) {
                toast({
                    variant: "destructive",
                    title: "Erro ao buscar leads",
                    description: "Não foi possível carregar a lista de leads.",
                });
            } finally {
                setIsLoading(false);
            }
        };
        fetchLeads();
    }, [toast]);

    const handleAdd = () => {
        setSelectedLead(null)
        setIsFormOpen(true)
    }

    const handleEdit = (lead: Lead) => {
        setSelectedLead(lead)
        setIsFormOpen(true)
    }

    const handleDelete = (lead: Lead) => {
        setSelectedLead(lead)
        setIsDeleteDialogOpen(true)
    }

    const confirmDelete = async () => {
        if (!selectedLead) return;
        try {
            await deleteLead(selectedLead.id);
            setLeads(leads.filter(l => l.id !== selectedLead.id))
            toast({ title: "Lead excluído", description: `O lead "${selectedLead.name}" foi excluído com sucesso.` })
        } catch (error) {
            toast({
                variant: "destructive",
                title: "Erro ao excluir",
                description: "Não foi possível excluir o lead.",
            });
        } finally {
            setIsDeleteDialogOpen(false)
            setSelectedLead(null)
        }
    }
    
    const handleConvert = async (leadToConvert: Lead) => {
        try {
            await convertLeadToCustomer(leadToConvert);
            setLeads(leads.filter(l => l.id !== leadToConvert.id));
            toast({
                title: "Lead Convertido!",
                description: `${leadToConvert.name} agora é um cliente.`,
            });
        } catch (error) {
            toast({
                variant: "destructive",
                title: "Erro ao converter",
                description: "Não foi possível converter o lead em cliente.",
            });
        }
    }

    const handleStatusChange = async (leadToUpdate: Lead, newStatus: Lead['status']) => {
        try {
            await updateLead(leadToUpdate.id, { status: newStatus });
            setLeads(leads.map(l => l.id === leadToUpdate.id ? { ...l, status: newStatus } : l));
            toast({
                title: "Status do Lead Atualizado",
                description: `O status de ${leadToUpdate.name} foi alterado para "${newStatus}".`
            })
        } catch(error) {
             toast({
                variant: "destructive",
                title: "Erro ao atualizar",
                description: "Não foi possível atualizar o status do lead.",
            });
        }
    }

    const handleFormSubmit = async (values: LeadFormValues) => {
        try {
            if (selectedLead) {
                // Update
                await updateLead(selectedLead.id, values);
                setLeads(leads.map(l => l.id === selectedLead.id ? { ...selectedLead, ...values } : l))
                toast({ title: "Lead atualizado", description: "Os dados do lead foram atualizados." })
            } else {
                // Create
                const newLead = await addLead(values);
                setLeads([newLead, ...leads])
                toast({ title: "Lead adicionado", description: "O novo lead foi adicionado à sua lista." })
            }
            setIsFormOpen(false)
            setSelectedLead(null)
        } catch(error) {
            toast({
                variant: "destructive",
                title: "Erro ao salvar",
                description: "Não foi possível salvar os dados do lead.",
            });
        }
    }

    const columns: ColumnDef<Lead>[] = [
      {
        id: "select",
        header: ({ table }) => (
          <Checkbox
            checked={table.getIsAllPageRowsSelected() || (table.getIsSomePageRowsSelected() && "indeterminate")}
            onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
            aria-label="Selecionar tudo"
          />
        ),
        cell: ({ row }) => (
          <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => row.toggleSelected(!!value)}
            aria-label="Selecionar linha"
          />
        ),
        enableSorting: false,
        enableHiding: false,
      },
      {
        accessorKey: "name",
        header: "Nome",
      },
      {
        accessorKey: "status",
        header: ({ column }) => (
          <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}>
            Status
            <CaretSortIcon className="ml-2 h-4 w-4" />
          </Button>
        ),
        cell: ({ row }) => {
            const status = row.getValue("status") as string;
            const variant = status === 'Qualificado' ? 'default' : status === 'Novo' ? 'secondary' : status === 'Contatado' ? 'outline' : 'destructive';
            const className = status === 'Qualificado' ? 'bg-accent text-accent-foreground' : '';
            return <Badge variant={variant} className={className}>{status}</Badge>
        }
      },
      {
        accessorKey: "email",
        header: "Email",
      },
        {
        accessorKey: "source",
        header: "Fonte",
      },
      {
        accessorKey: "assignedTo",
        header: "Atribuído a",
      },
      {
        accessorKey: "createdAt",
        header: "Criado em",
         cell: ({ row }) => {
            const date = row.getValue("createdAt") as any;
            if (date && typeof date.toDate === 'function') {
                return new Date(date.toDate()).toLocaleDateString('pt-BR');
            }
            if (date && typeof date === 'string') {
                return new Date(date).toLocaleDateString('pt-BR');
            }
            return 'Data inválida';
        },
      },
      {
        id: "actions",
        cell: ({ row }) => {
          const lead = row.original
          return (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="h-8 w-8 p-0">
                  <span className="sr-only">Abrir menu</span>
                  <DotsHorizontalIcon className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Ações</DropdownMenuLabel>
                <DropdownMenuItem onClick={() => handleConvert(lead)}>Converter em Cliente</DropdownMenuItem>
                
                <DropdownMenuSub>
                    <DropdownMenuSubTrigger>Atualizar Status</DropdownMenuSubTrigger>
                    <DropdownMenuSubContent>
                        <DropdownMenuRadioGroup 
                            value={lead.status} 
                            onValueChange={(newStatus) => handleStatusChange(lead, newStatus as Lead['status'])}
                        >
                        {leadStatuses.map(status => (
                            <DropdownMenuRadioItem key={status} value={status}>{status}</DropdownMenuRadioItem>
                        ))}
                        </DropdownMenuRadioGroup>
                    </DropdownMenuSubContent>
                </DropdownMenuSub>

                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => handleEdit(lead)}>Editar Lead</DropdownMenuItem>
                <DropdownMenuItem className="text-destructive" onClick={() => handleDelete(lead)}>Excluir Lead</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )
        },
      },
    ]

    return (
        <>
            <LeadForm
                isOpen={isFormOpen}
                onOpenChange={setIsFormOpen}
                onSubmit={handleFormSubmit}
                defaultValues={selectedLead}
            />

            <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Você tem certeza?</AlertDialogTitle>
                        <AlertDialogDescription>
                            Essa ação não pode ser desfeita. Isso excluirá permanentemente o lead de <span className="font-semibold">"{selectedLead?.name}"</span>.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                        <AlertDialogAction onClick={confirmDelete} className="bg-destructive hover:bg-destructive/90">Excluir</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>

            <div className="flex flex-col gap-6">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight font-headline">Leads</h1>
                        <p className="text-muted-foreground">
                            Nutra clientes em potencial desde o contato inicial até a qualificação.
                        </p>
                    </div>
                    <Button onClick={handleAdd}>Adicionar Lead</Button>
                </div>
                 {isLoading ? (
                    <div className="flex items-center justify-center p-8">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                         <p className="ml-4">Carregando leads...</p>
                    </div>
                ) : (
                    <DataTable 
                        columns={columns} 
                        data={leads}
                        filterColumnId="name"
                        filterPlaceholder="Filtrar por nome..."
                    />
                )}
            </div>
        </>
    )
}
