
"use client"

import * as React from "react"
import {
  CaretSortIcon,
  DotsHorizontalIcon,
} from "@radix-ui/react-icons"
import {
  ColumnDef,
} from "@tanstack/react-table"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { DataTable } from "@/components/data-table"
import type { Customer } from "@/lib/types"
import { useToast } from "@/hooks/use-toast"
import { CustomerForm, type CustomerFormValues } from "@/components/forms/customer-form"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { getCustomers, addCustomer, updateCustomer, deleteCustomer } from "@/services/customer-service"
import { Loader2 } from "lucide-react"

export default function CustomersPage() {
    const { toast } = useToast()
    const [customers, setCustomers] = React.useState<Customer[]>([])
    const [isLoading, setIsLoading] = React.useState(true)
    const [isFormOpen, setIsFormOpen] = React.useState(false)
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = React.useState(false)
    const [selectedCustomer, setSelectedCustomer] = React.useState<Customer | null>(null)

    React.useEffect(() => {
        const fetchCustomers = async () => {
            try {
                const customersData = await getCustomers();
                setCustomers(customersData);
            } catch (error) {
                toast({
                    variant: "destructive",
                    title: "Erro ao buscar clientes",
                    description: "Não foi possível carregar a lista de clientes.",
                });
            } finally {
                setIsLoading(false);
            }
        };
        fetchCustomers();
    }, [toast]);


    const handleAdd = () => {
        setSelectedCustomer(null)
        setIsFormOpen(true)
    }

    const handleEdit = (customer: Customer) => {
        setSelectedCustomer(customer)
        setIsFormOpen(true)
    }

    const handleDelete = (customer: Customer) => {
        setSelectedCustomer(customer)
        setIsDeleteDialogOpen(true)
    }

    const confirmDelete = async () => {
        if (!selectedCustomer) return;
        try {
            await deleteCustomer(selectedCustomer.id);
            setCustomers(customers.filter(c => c.id !== selectedCustomer.id))
            toast({ title: "Cliente excluído", description: `O cliente "${selectedCustomer.name}" foi excluído com sucesso.` })
        } catch (error) {
             toast({
                variant: "destructive",
                title: "Erro ao excluir",
                description: "Não foi possível excluir o cliente.",
            });
        } finally {
            setIsDeleteDialogOpen(false)
            setSelectedCustomer(null)
        }
    }

    const handleFormSubmit = async (values: CustomerFormValues) => {
        try {
            if (selectedCustomer) {
                // Update
                await updateCustomer(selectedCustomer.id, values);
                setCustomers(customers.map(c => c.id === selectedCustomer.id ? { ...c, ...values } : c))
                toast({ title: "Cliente atualizado", description: "Os dados do cliente foram atualizados." })
            } else {
                // Create
                const newCustomer = await addCustomer(values);
                setCustomers([newCustomer, ...customers])
                toast({ title: "Cliente adicionado", description: "O novo cliente foi adicionado à sua lista." })
            }
            setIsFormOpen(false)
            setSelectedCustomer(null)
        } catch (error) {
            toast({
                variant: "destructive",
                title: "Erro ao salvar",
                description: "Não foi possível salvar os dados do cliente.",
            });
        }
    }

    const columns: ColumnDef<Customer>[] = [
      {
        id: "select",
        header: ({ table }) => (
          <Checkbox
            checked={
              table.getIsAllPageRowsSelected() ||
              (table.getIsSomePageRowsSelected() && "indeterminate")
            }
            onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
            aria-label="Selecionar tudo"
          />
        ),
        cell: ({ row }) => (
          <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => row.toggleSelected(!!value)}
            aria-label="Selecionar linha"
          />
        ),
        enableSorting: false,
        enableHiding: false,
      },
      {
        accessorKey: "name",
        header: ({ column }) => {
          return (
            <Button
              variant="ghost"
              onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            >
              Nome
              <CaretSortIcon className="ml-2 h-4 w-4" />
            </Button>
          )
        },
        cell: ({ row }) => <div className="capitalize">{row.getValue("name")}</div>,
      },
      {
        accessorKey: "email",
        header: "Email",
        cell: ({ row }) => <div className="lowercase">{row.getValue("email")}</div>,
      },
      {
        accessorKey: "phone",
        header: "Telefone",
      },
        {
        accessorKey: "company",
        header: "Empresa",
      },
      {
        accessorKey: "createdAt",
        header: "Criado em",
         cell: ({ row }) => {
            const date = row.getValue("createdAt") as any;
            // Check if it's a Firestore Timestamp and convert
            if (date && typeof date.toDate === 'function') {
                return new Date(date.toDate()).toLocaleDateString('pt-BR');
            }
             // Check if it's an ISO string or other date format
            if (date && typeof date === 'string') {
                return new Date(date).toLocaleDateString('pt-BR');
            }
            return 'Data inválida';
        },
      },
      {
        id: "actions",
        enableHiding: false,
        cell: ({ row }) => {
            const customer = row.original
            return (
                <DropdownMenu>
                <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="h-8 w-8 p-0">
                    <span className="sr-only">Abrir menu</span>
                    <DotsHorizontalIcon className="h-4 w-4" />
                    </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Ações</DropdownMenuLabel>
                    <DropdownMenuItem
                    onClick={() => navigator.clipboard.writeText(row.original.id)}
                    >
                    Copiar ID do cliente
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => handleEdit(customer)}>Editar cliente</DropdownMenuItem>
                    <DropdownMenuItem className="text-destructive" onClick={() => handleDelete(customer)}>Excluir cliente</DropdownMenuItem>
                </DropdownMenuContent>
                </DropdownMenu>
            )
        },
      },
    ]


    return (
        <>
            <CustomerForm
                isOpen={isFormOpen}
                onOpenChange={setIsFormOpen}
                onSubmit={handleFormSubmit}
                defaultValues={selectedCustomer}
            />

             <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Você tem certeza?</AlertDialogTitle>
                        <AlertDialogDescription>
                            Essa ação não pode ser desfeita. Isso excluirá permanentemente o cliente
                             <span className="font-semibold">"{selectedCustomer?.name}"</span>.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                        <AlertDialogAction onClick={confirmDelete} className="bg-destructive hover:bg-destructive/90">Excluir</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>


            <div className="flex flex-col gap-6">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight font-headline">
                            Clientes
                        </h1>
                        <p className="text-muted-foreground">
                            Gerencie sua base de clientes.
                        </p>
                    </div>
                    <Button onClick={handleAdd}>Adicionar Cliente</Button>
                </div>
                {isLoading ? (
                    <div className="flex items-center justify-center p-8">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                         <p className="ml-4">Carregando clientes...</p>
                    </div>
                ) : (
                    <DataTable 
                        columns={columns} 
                        data={customers}
                        filterColumnId="name"
                        filterPlaceholder="Filtrar por nome..."
                    />
                )}
            </div>
        </>
    )
}
