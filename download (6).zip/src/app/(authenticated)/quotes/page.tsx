"use client"

import * as React from "react"
import { CaretSortIcon, DotsHorizontalIcon } from "@radix-ui/react-icons"
import { ColumnDef } from "@tanstack/react-table"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { DataTable } from "@/components/data-table"
import type { Quote } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { QuoteForm, QuoteFormValues } from "@/components/forms/quote-form"
import { getQuotes, addQuote, updateQuote } from "@/services/quote-service"
import { Loader2 } from "lucide-react"

const handleDownloadPdf = (quoteId: string) => {
    alert(`Funcionalidade de download do PDF para a cotação ${quoteId} ainda não implementada.`);
};

export default function QuotesPage() {
    const { toast } = useToast()
    const [quotes, setQuotes] = React.useState<Quote[]>([])
    const [isLoading, setIsLoading] = React.useState(true)
    const [isFormOpen, setIsFormOpen] = React.useState(false)
    const [selectedQuote, setSelectedQuote] = React.useState<Quote | null>(null)

    React.useEffect(() => {
        const fetchQuotes = async () => {
            try {
                const quotesData = await getQuotes();
                setQuotes(quotesData);
            } catch (error) {
                 toast({
                    variant: "destructive",
                    title: "Erro ao buscar cotações",
                    description: "Não foi possível carregar a lista de cotações.",
                });
            } finally {
                setIsLoading(false);
            }
        };
        fetchQuotes();
    }, [toast]);
    
    const handleAdd = () => {
        setSelectedQuote(null)
        setIsFormOpen(true)
    }

    const handleViewDetails = (quote: Quote) => {
        setSelectedQuote(quote)
        setIsFormOpen(true)
    }

    const handleFormSubmit = async (values: QuoteFormValues) => {
        try {
            if (selectedQuote) {
                // Update (Note: In a real app, editing a quote might have restrictions)
                const updatedQuote = { ...selectedQuote, ...values };
                await updateQuote(selectedQuote.id, values);
                setQuotes(quotes.map(q => q.id === selectedQuote.id ? updatedQuote : q))
                toast({ title: "Cotação atualizada", description: "Os dados da cotação foram atualizados." })
            } else {
                // Create
                const newQuote = await addQuote(values);
                setQuotes([newQuote, ...quotes])
                toast({ title: "Cotação criada", description: "A nova cotação foi criada com sucesso." })
            }
            setIsFormOpen(false)
            setSelectedQuote(null)
        } catch(error) {
             toast({
                variant: "destructive",
                title: "Erro ao salvar",
                description: "Não foi possível salvar os dados da cotação.",
            });
        }
    }

    const columns: ColumnDef<Quote>[] = [
      {
        id: "select",
        header: ({ table }) => (
          <Checkbox
            checked={table.getIsAllPageRowsSelected()}
            onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
            aria-label="Selecionar tudo"
          />
        ),
        cell: ({ row }) => (
          <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => row.toggleSelected(!!value)}
            aria-label="Selecionar linha"
          />
        ),
      },
      {
        accessorKey: "id",
        header: "ID da Cotação",
      },
      {
        accessorKey: "customerName",
        header: "Cliente",
      },
        {
        accessorKey: "total",
        header: ({ column }) => (
          <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}>
            Total
            <CaretSortIcon className="ml-2 h-4 w-4" />
          </Button>
        ),
        cell: ({ row }) => {
          const total = parseFloat(row.getValue("total"))
          const formatted = new Intl.NumberFormat("pt-BR", {
            style: "currency",
            currency: "BRL",
          }).format(total)
          return <div className="font-medium">{formatted}</div>
        },
      },
      {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.getValue("status") as string;
            const variant = status === 'Aceito' ? 'default' : status === 'Enviado' ? 'secondary' : 'destructive';
            const className = status === 'Aceito' ? 'bg-accent text-accent-foreground' : '';
            return <Badge variant={variant} className={className}>{status}</Badge>
        }
      },
      {
        accessorKey: "createdAt",
        header: "Criado em",
        cell: ({ row }) => {
            const date = row.getValue("createdAt") as any;
            if (date && typeof date.toDate === 'function') {
                return new Date(date.toDate()).toLocaleDateString('pt-BR');
            }
            if (date && typeof date === 'string') {
                return new Date(date).toLocaleDateString('pt-BR');
            }
            return 'Data inválida';
        },
      },
      {
        accessorKey: "expiresAt",
        header: "Expira em",
         cell: ({ row }) => {
            const date = row.getValue("expiresAt") as any;
            if (date && typeof date.toDate === 'function') {
                return new Date(date.toDate()).toLocaleDateString('pt-BR');
            }
            if (date && typeof date === 'string') {
                return new Date(date).toLocaleDateString('pt-BR');
            }
            return 'Data inválida';
        },
      },
      {
        id: "actions",
        cell: ({ row }) => {
            const quote = row.original
            return (
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="h-8 w-8 p-0">
                        <span className="sr-only">Abrir menu</span>
                        <DotsHorizontalIcon className="h-4 w-4" />
                    </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Ações</DropdownMenuLabel>
                    <DropdownMenuItem onClick={() => handleViewDetails(quote)}>Ver Detalhes</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleDownloadPdf(quote.id)}>Baixar PDF</DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>
            )
        },
      },
    ]

    return (
        <>
            <QuoteForm
                isOpen={isFormOpen}
                onOpenChange={setIsFormOpen}
                onSubmit={handleFormSubmit}
                defaultValues={selectedQuote}
            />
            <div className="flex flex-col gap-6">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight font-headline">Cotações</h1>
                        <p className="text-muted-foreground">
                            Crie, envie e acompanhe cotações de vendas.
                        </p>
                    </div>
                    <Button onClick={handleAdd}>Criar Cotação</Button>
                </div>
                 {isLoading ? (
                    <div className="flex items-center justify-center p-8">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                         <p className="ml-4">Carregando cotações...</p>
                    </div>
                ) : (
                    <DataTable 
                        columns={columns} 
                        data={quotes}
                        filterColumnId="customerName"
                        filterPlaceholder="Filtrar por cliente..."
                    />
                )}
            </div>
        </>
    )
}
