"use client"

import * as React from "react"
import { CaretSortIcon, DotsHorizontalIcon } from "@radix-ui/react-icons"
import { ColumnDef } from "@tanstack/react-table"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { DataTable } from "@/components/data-table"
import type { Sale } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { SaleForm, SaleFormValues } from "@/components/forms/sale-form"
import { addSale, getSales, updateSale } from "@/services/sales-service"
import { Loader2 } from "lucide-react"

export default function SalesPage() {
    const { toast } = useToast()
    const [sales, setSales] = React.useState<Sale[]>([])
    const [isLoading, setIsLoading] = React.useState(true)
    const [isFormOpen, setIsFormOpen] = React.useState(false)
    const [selectedSale, setSelectedSale] = React.useState<Sale | null>(null)

    React.useEffect(() => {
        const fetchSales = async () => {
            try {
                const salesData = await getSales();
                setSales(salesData);
            } catch (error) {
                 toast({
                    variant: "destructive",
                    title: "Erro ao buscar vendas",
                    description: "Não foi possível carregar a lista de vendas.",
                });
            } finally {
                setIsLoading(false);
            }
        };
        fetchSales();
    }, [toast]);

    const handleAdd = () => {
        setSelectedSale(null)
        setIsFormOpen(true)
    }

    const handleEdit = (sale: Sale) => {
        setSelectedSale(sale)
        setIsFormOpen(true)
    }
    
    const handleViewDetails = (sale: Sale) => {
        toast({
            title: `Venda ID: ${sale.id}`,
            description: (
                <pre className="mt-2 w-[340px] rounded-md bg-slate-950 p-4">
                    <code className="text-white">{JSON.stringify(sale, null, 2)}</code>
                </pre>
            ),
        })
    }

    const handleFormSubmit = async (values: SaleFormValues) => {
        try {
            if (selectedSale) {
                // Update
                const updatedSale = { ...selectedSale, ...values };
                await updateSale(selectedSale.id, values);
                setSales(sales.map(s => s.id === selectedSale.id ? updatedSale : s))
                toast({ title: "Venda atualizada", description: "Os dados da venda foram atualizados." })
            } else {
                // Create
                const newSale = await addSale(values);
                setSales([newSale, ...sales])
                toast({ title: "Venda adicionada", description: "A nova venda foi registrada." })
            }
            setIsFormOpen(false)
            setSelectedSale(null)
        } catch(error) {
             toast({
                variant: "destructive",
                title: "Erro ao salvar",
                description: "Não foi possível salvar os dados da venda.",
            });
        }
    }

    const columns: ColumnDef<Sale>[] = [
      {
        id: "select",
        header: ({ table }) => (
          <Checkbox
            checked={table.getIsAllPageRowsSelected() || (table.getIsSomePageRowsSelected() && "indeterminate")}
            onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
            aria-label="Selecionar tudo"
          />
        ),
        cell: ({ row }) => (
          <Checkbox
            checked={row.getIsSelected()}
            onCheckedChange={(value) => row.toggleSelected(!!value)}
            aria-label="Selecionar linha"
          />
        ),
        enableSorting: false,
        enableHiding: false,
      },
      {
        accessorKey: "customerName",
        header: "Cliente",
      },
      {
        accessorKey: "product",
        header: "Produto",
      },
      {
        accessorKey: "amount",
        header: ({ column }) => {
          return (
            <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}>
              Valor
              <CaretSortIcon className="ml-2 h-4 w-4" />
            </Button>
          )
        },
        cell: ({ row }) => {
          const amount = parseFloat(row.getValue("amount"))
          const formatted = new Intl.NumberFormat("pt-BR", {
            style: "currency",
            currency: "BRL",
          }).format(amount)

          return <div className="text-left font-medium">{formatted}</div>
        },
      },
      {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.getValue("status") as string;
            const variant = status === 'Concluída' ? 'default' : status === 'Pendente' ? 'secondary' : 'destructive'
            return <Badge variant={variant} className={status === 'Concluída' ? 'bg-accent text-accent-foreground' : ''}>{status}</Badge>
        }
      },
      {
        accessorKey: "representativeName",
        header: "Representante",
      },
      {
        accessorKey: "date",
        header: "Data",
        cell: ({ row }) => {
            const date = row.getValue("date") as any;
            // Check if it's a Firestore Timestamp and convert
            if (date && typeof date.toDate === 'function') {
                return new Date(date.toDate()).toLocaleDateString('pt-BR');
            }
             // Check if it's an ISO string or other date format
            if (date && typeof date === 'string') {
                return new Date(date).toLocaleDateString('pt-BR');
            }
            return 'Data inválida';
        },
      },
      {
        id: "actions",
        cell: ({ row }) => {
          const sale = row.original
          return (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="h-8 w-8 p-0">
                  <span className="sr-only">Abrir menu</span>
                  <DotsHorizontalIcon className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Ações</DropdownMenuLabel>
                <DropdownMenuItem onClick={() => handleViewDetails(sale)}>Ver detalhes da venda</DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleEdit(sale)}>Editar venda</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )
        },
      },
    ]

    return (
        <>
            <SaleForm 
                isOpen={isFormOpen}
                onOpenChange={setIsFormOpen}
                onSubmit={handleFormSubmit}
                defaultValues={selectedSale}
            />
            <div className="flex flex-col gap-6">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight font-headline">Vendas</h1>
                        <p className="text-muted-foreground">
                            Acompanhe e gerencie todas as vendas.
                        </p>
                    </div>
                    <Button onClick={handleAdd}>Adicionar Venda</Button>
                </div>
                 {isLoading ? (
                    <div className="flex items-center justify-center p-8">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                         <p className="ml-4">Carregando vendas...</p>
                    </div>
                ) : (
                    <DataTable 
                        columns={columns} 
                        data={sales}
                        filterColumnId="customerName"
                        filterPlaceholder="Filtrar por cliente..."
                    />
                )}
            </div>
        </>
    )
}
