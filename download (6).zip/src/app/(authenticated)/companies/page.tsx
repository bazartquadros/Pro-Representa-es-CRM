"use client"

import * as React from "react"
import { CaretSortIcon, DotsHorizontalIcon } from "@radix-ui/react-icons"
import { ColumnDef } from "@tanstack/react-table"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { DataTable } from "@/components/data-table"
import type { Company } from "@/lib/types"
import { useToast } from "@/hooks/use-toast"
import { CompanyForm, CompanyFormValues } from "@/components/forms/company-form"
import { getCompanies, addCompany, updateCompany } from "@/services/company-service"
import { Loader2 } from "lucide-react"

export default function CompaniesPage() {
    const { toast } = useToast()
    const [companies, setCompanies] = React.useState<Company[]>([])
    const [isLoading, setIsLoading] = React.useState(true)
    const [isFormOpen, setIsFormOpen] = React.useState(false)
    const [selectedCompany, setSelectedCompany] = React.useState<Company | null>(null)

    React.useEffect(() => {
        const fetchCompanies = async () => {
            try {
                const companiesData = await getCompanies();
                setCompanies(companiesData);
            } catch (error) {
                 toast({
                    variant: "destructive",
                    title: "Erro ao buscar empresas",
                    description: "Não foi possível carregar a lista de empresas.",
                });
            } finally {
                setIsLoading(false);
            }
        };
        fetchCompanies();
    }, [toast]);


    const handleAdd = () => {
        setSelectedCompany(null)
        setIsFormOpen(true)
    }

    const handleEdit = (company: Company) => {
        setSelectedCompany(company)
        setIsFormOpen(true)
    }
    
    const handleViewDetails = (company: Company) => {
        toast({
            title: `Detalhes de: ${company.name}`,
            description: (
                <pre className="mt-2 w-[340px] rounded-md bg-slate-950 p-4">
                    <code className="text-white">{JSON.stringify(company, null, 2)}</code>
                </pre>
            ),
        })
    }

    const handleFormSubmit = async (values: CompanyFormValues) => {
        try {
            if (selectedCompany) {
                // Update
                await updateCompany(selectedCompany.id, values);
                setCompanies(companies.map(c => c.id === selectedCompany.id ? { ...c, ...values } : c))
                toast({ title: "Empresa atualizada", description: "Os dados da empresa foram atualizados." })
            } else {
                // Create
                const newCompany = await addCompany(values);
                setCompanies([newCompany, ...companies])
                toast({ title: "Empresa adicionada", description: "A nova empresa foi adicionada à sua lista." })
            }
            setIsFormOpen(false)
            setSelectedCompany(null)
        } catch(error) {
             toast({
                variant: "destructive",
                title: "Erro ao salvar",
                description: "Não foi possível salvar os dados da empresa.",
            });
        }
    }

    const columns: ColumnDef<Company>[] = [
        {
            id: "select",
            header: ({ table }) => (
            <Checkbox
                checked={table.getIsAllPageRowsSelected()}
                onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
                aria-label="Selecionar tudo"
            />
            ),
            cell: ({ row }) => (
            <Checkbox
                checked={row.getIsSelected()}
                onCheckedChange={(value) => row.toggleSelected(!!value)}
                aria-label="Selecionar linha"
            />
            ),
        },
        {
            accessorKey: "name",
            header: ({ column }) => (
            <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}>
                Nome da Empresa
                <CaretSortIcon className="ml-2 h-4 w-4" />
            </Button>
            ),
        },
        {
            accessorKey: "industry",
            header: "Setor",
        },
        {
            accessorKey: "contactPerson",
            header: "Pessoa de Contato",
        },
        {
            accessorKey: "contactEmail",
            header: "Email de Contato",
        },
        {
            id: "actions",
            cell: ({ row }) => {
                const company = row.original
                return (
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Abrir menu</span>
                            <DotsHorizontalIcon className="h-4 w-4" />
                        </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Ações</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => handleViewDetails(company)}>Ver Detalhes</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleEdit(company)}>Editar Empresa</DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                )
            },
        },
    ]

    return (
        <>
            <CompanyForm
                isOpen={isFormOpen}
                onOpenChange={setIsFormOpen}
                onSubmit={handleFormSubmit}
                defaultValues={selectedCompany}
            />

            <div className="flex flex-col gap-6">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight font-headline">Empresas Representadas</h1>
                        <p className="text-muted-foreground">
                            Gerencie as empresas que você representa.
                        </p>
                    </div>
                    <Button onClick={handleAdd}>Adicionar Empresa</Button>
                </div>
                 {isLoading ? (
                    <div className="flex items-center justify-center p-8">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                         <p className="ml-4">Carregando empresas...</p>
                    </div>
                ) : (
                    <DataTable 
                        columns={columns} 
                        data={companies}
                        filterColumnId="name"
                        filterPlaceholder="Filtrar por nome..."
                    />
                )}
            </div>
        </>
    )
}
