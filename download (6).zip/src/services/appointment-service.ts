
import { db } from "@/lib/firebase";
import { collection, getDocs, addDoc, doc, updateDoc, deleteDoc, query, orderBy } from "firebase/firestore";
import type { Appointment } from "@/lib/types";
import { AppointmentFormValues } from "@/components/forms/appointment-form";

const appointmentsCollection = collection(db, "appointments");

export async function getAppointments(): Promise<Appointment[]> {
    const q = query(appointmentsCollection, orderBy("dateTime", "desc"));
    const snapshot = await getDocs(q);
    const appointments = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
            ...data,
            id: doc.id,
            dateTime: data.dateTime.toDate().toISOString(),
        } as Appointment;
    });
    return appointments;
}

export async function addAppointment(appointmentData: AppointmentFormValues): Promise<Appointment> {
    const docRef = await addDoc(appointmentsCollection, {
        ...appointmentData,
        status: 'Agendado',
    });
    return { 
        ...appointmentData, 
        id: docRef.id, 
        status: 'Agendado',
        dateTime: appointmentData.dateTime.toISOString() 
    };
}

export async function updateAppointment(id: string, appointmentData: Partial<AppointmentFormValues & { status: Appointment['status'] }>): Promise<void> {
    const appointmentDoc = doc(db, "appointments", id);
    await updateDoc(appointmentDoc, appointmentData);
}

export async function deleteAppointment(id: string): Promise<void> {
    const appointmentDoc = doc(db, "appointments", id);
    await deleteDoc(appointmentDoc);
}
