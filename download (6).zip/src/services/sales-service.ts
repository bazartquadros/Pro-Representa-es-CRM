
import { db } from "@/lib/firebase";
import { collection, getDocs, addDoc, doc, updateDoc, deleteDoc, serverTimestamp, query, orderBy } from "firebase/firestore";
import type { Sale } from "@/lib/types";
import { SaleFormValues } from "@/components/forms/sale-form";

const salesCollection = collection(db, "sales");

export async function getSales(): Promise<Sale[]> {
    const q = query(salesCollection, orderBy("date", "desc"));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Sale));
}

export async function addSale(saleData: SaleFormValues): Promise<Sale> {
    const docRef = await addDoc(salesCollection, {
        ...saleData,
        date: serverTimestamp(),
    });
    return { ...saleData, id: docRef.id, date: new Date().toISOString() };
}

export async function updateSale(id: string, saleData: Partial<SaleFormValues>): Promise<void> {
    const saleDoc = doc(db, "sales", id);
    await updateDoc(saleDoc, saleData);
}

export async function deleteSale(id: string): Promise<void> {
    const saleDoc = doc(db, "sales", id);
    await deleteDoc(saleDoc);
}
