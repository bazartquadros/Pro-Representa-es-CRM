
import { db } from "@/lib/firebase";
import { collection, getDocs, addDoc, doc, updateDoc, deleteDoc, query, orderBy } from "firebase/firestore";
import type { User } from "@/lib/types";
import { UserFormValues } from "@/components/forms/user-form";

const usersCollection = collection(db, "users");

export async function getUsers(): Promise<User[]> {
    const q = query(usersCollection, orderBy("name"));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as User));
}

export async function addUser(userData: UserFormValues): Promise<User> {
    const docRef = await addDoc(usersCollection, userData);
    return { ...userData, id: docRef.id };
}

export async function updateUser(id: string, userData: Partial<UserFormValues>): Promise<void> {
    const userDoc = doc(db, "users", id);
    await updateDoc(userDoc, userData);
}

export async function deleteUser(id: string): Promise<void> {
    const userDoc = doc(db, "users", id);
    await deleteDoc(userDoc);
}
