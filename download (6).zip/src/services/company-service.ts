
import { db } from "@/lib/firebase";
import { collection, getDocs, addDoc, doc, updateDoc, deleteDoc, query, orderBy } from "firebase/firestore";
import type { Company } from "@/lib/types";
import { CompanyFormValues } from "@/components/forms/company-form";

const companiesCollection = collection(db, "companies");

export async function getCompanies(): Promise<Company[]> {
    const q = query(companiesCollection, orderBy("name"));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Company));
}

export async function addCompany(companyData: CompanyFormValues): Promise<Company> {
    const docRef = await addDoc(companiesCollection, companyData);
    return { ...companyData, id: docRef.id };
}

export async function updateCompany(id: string, companyData: CompanyFormValues): Promise<void> {
    const companyDoc = doc(db, "companies", id);
    await updateDoc(companyDoc, companyData);
}

export async function deleteCompany(id: string): Promise<void> {
    const companyDoc = doc(db, "companies", id);
    await deleteDoc(companyDoc);
}
