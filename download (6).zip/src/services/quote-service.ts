
import { db } from "@/lib/firebase";
import { collection, getDocs, addDoc, doc, updateDoc, deleteDoc, serverTimestamp, query, orderBy } from "firebase/firestore";
import type { Quote } from "@/lib/types";
import { QuoteFormValues } from "@/components/forms/quote-form";

const quotesCollection = collection(db, "quotes");

export async function getQuotes(): Promise<Quote[]> {
    const q = query(quotesCollection, orderBy("createdAt", "desc"));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Quote));
}

export async function addQuote(quoteData: QuoteFormValues): Promise<Quote> {
    const total = quoteData.items.reduce((acc, item) => acc + item.quantity * item.price, 0);
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 30);

    const docRef = await addDoc(quotesCollection, {
        ...quoteData,
        total,
        status: 'Enviado',
        createdAt: serverTimestamp(),
        expiresAt: expiresAt,
    });
    
    return { 
        ...quoteData, 
        id: docRef.id, 
        total, 
        status: 'Enviado', 
        createdAt: new Date().toISOString(), 
        expiresAt: expiresAt.toISOString()
    };
}

export async function updateQuote(id: string, quoteData: QuoteFormValues): Promise<void> {
    const total = quoteData.items.reduce((acc, item) => acc + item.quantity * item.price, 0);
    const quoteDoc = doc(db, "quotes", id);
    await updateDoc(quoteDoc, {
        ...quoteData,
        total,
    });
}

export async function deleteQuote(id: string): Promise<void> {
    const quoteDoc = doc(db, "quotes", id);
    await deleteDoc(quoteDoc);
}
