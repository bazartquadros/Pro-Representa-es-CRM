
import { db } from "@/lib/firebase";
import { collection, getDocs, addDoc, doc, updateDoc, deleteDoc, serverTimestamp, query, orderBy } from "firebase/firestore";
import type { Customer, CustomerFormValues } from "@/lib/types";

const customersCollection = collection(db, "customers");

export async function getCustomers(): Promise<Customer[]> {
    const q = query(customersCollection, orderBy("createdAt", "desc"));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Customer));
}

export async function addCustomer(customerData: CustomerFormValues): Promise<Customer> {
    const docRef = await addDoc(customersCollection, {
        ...customerData,
        createdAt: serverTimestamp(),
    });
    return { ...customerData, id: docRef.id, createdAt: new Date().toISOString() };
}

export async function updateCustomer(id: string, customerData: CustomerFormValues): Promise<void> {
    const customerDoc = doc(db, "customers", id);
    await updateDoc(customerDoc, customerData);
}

export async function deleteCustomer(id: string): Promise<void> {
    const customerDoc = doc(db, "customers", id);
    await deleteDoc(customerDoc);
}
