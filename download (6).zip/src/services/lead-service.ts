
import { db } from "@/lib/firebase";
import { collection, getDocs, addDoc, doc, updateDoc, deleteDoc, serverTimestamp, query, orderBy, writeBatch } from "firebase/firestore";
import type { Lead } from "@/lib/types";
import { LeadFormValues } from "@/components/forms/lead-form";

const leadsCollection = collection(db, "leads");
const customersCollection = collection(db, "customers");

export async function getLeads(): Promise<Lead[]> {
    const q = query(leadsCollection, orderBy("createdAt", "desc"));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Lead));
}

export async function addLead(leadData: LeadFormValues): Promise<Lead> {
    const docRef = await addDoc(leadsCollection, {
        ...leadData,
        status: 'Novo',
        createdAt: serverTimestamp(),
    });
    return { ...leadData, id: docRef.id, status: 'Novo', createdAt: new Date().toISOString() };
}

export async function updateLead(id: string, leadData: Partial<LeadFormValues | { status: Lead['status'] }>): Promise<void> {
    const leadDoc = doc(db, "leads", id);
    await updateDoc(leadDoc, leadData);
}

export async function deleteLead(id: string): Promise<void> {
    const leadDoc = doc(db, "leads", id);
    await deleteDoc(leadDoc);
}

export async function convertLeadToCustomer(lead: Lead): Promise<void> {
    const batch = writeBatch(db);

    // 1. Create a new customer
    const newCustomerRef = doc(customersCollection);
    batch.set(newCustomerRef, {
        name: lead.name,
        email: lead.email,
        phone: lead.phone,
        company: lead.company,
        createdAt: serverTimestamp(),
    });

    // 2. Delete the lead
    const leadRef = doc(db, "leads", lead.id);
    batch.delete(leadRef);

    // Commit the batch
    await batch.commit();
}
