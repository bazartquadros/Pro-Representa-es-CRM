"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Wand2, Loader2 } from "lucide-react";
import { getAiGuidanceForDeal, type GetAiGuidanceForDealInput } from "@/ai/flows/get-ai-guidance-for-deal";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export function AiGuidance() {
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [guidance, setGuidance] = useState<string | null>(null);
  const { toast } = useToast();

  const handleGetGuidance = async () => {
    setIsLoading(true);
    setGuidance(null);
    try {
      const input: GetAiGuidanceForDealInput = {
        dealHistory: "Cliente inicialmente interessado no Produto A. Ligação de acompanhamento revelou restrições orçamentárias. Mostrou interesse no Produto B (custo menor), mas está preocupado com o conjunto de recursos. Último contato foi há 1 semana.",
        customerDetails: "Empresa de e-commerce de médio porte buscando otimizar sua logística. O tomador de decisão é o CTO, que é orientado por dados e focado em ROI.",
      };
      const result = await getAiGuidanceForDeal(input);
      setGuidance(result.suggestions);
    } catch (error) {
      console.error("Erro na Orientação da IA:", error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Falha ao obter orientação da IA. Por favor, tente novamente.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button>
          <Wand2 className="mr-2 h-4 w-4" />
          Obter Orientação da IA
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="font-headline">Orientação de Negócio com IA</DialogTitle>
          <DialogDescription>
            Receba sugestões da IA para o seu negócio atual.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4">
          {!guidance && !isLoading && (
             <Alert>
                <Wand2 className="h-4 w-4" />
                <AlertTitle>Pronto para sugestões?</AlertTitle>
                <AlertDescription>
                    Clique no botão abaixo para gerar pontos de discussão e estratégias com a tecnologia de IA para este negócio.
                </AlertDescription>
            </Alert>
          )}

          {isLoading && (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="ml-4">Gerando orientação...</p>
            </div>
          )}

          {guidance && (
            <div className="prose prose-sm dark:prose-invert max-w-none rounded-md border bg-secondary/30 p-4">
                <h3 className="font-headline text-lg">Sugestões</h3>
                <p>{guidance}</p>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button onClick={handleGetGuidance} disabled={isLoading}>
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Wand2 className="mr-2 h-4 w-4" />}
            Gerar Orientação
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
