"use client"

import * as React from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm, useFieldArray } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Quote, Customer, User } from "@/lib/types"
import { TrashIcon } from "@radix-ui/react-icons"
import { getCustomers } from "@/services/customer-service"
import { getUsers } from "@/services/user-service"
import { Loader2 } from "lucide-react"

const quoteItemSchema = z.object({
  description: z.string().min(1, "Descrição é obrigatória"),
  quantity: z.coerce.number().min(1, "Quantidade deve ser pelo menos 1"),
  price: z.coerce.number().min(0, "Preço não pode ser negativo"),
});

const formSchema = z.object({
  customerName: z.string().min(1, "Selecione um cliente."),
  representativeName: z.string().min(1, "Selecione um representante."),
  items: z.array(quoteItemSchema).min(1, "Adicione pelo menos um item à cotação."),
})

export type QuoteFormValues = z.infer<typeof formSchema>

type QuoteFormProps = {
  isOpen: boolean
  onOpenChange: (isOpen: boolean) => void
  onSubmit: (values: QuoteFormValues) => void
  defaultValues?: Quote | null
}

export function QuoteForm({ isOpen, onOpenChange, onSubmit, defaultValues }: QuoteFormProps) {
  const [customers, setCustomers] = React.useState<Customer[]>([]);
  const [representatives, setRepresentatives] = React.useState<User[]>([]);
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const form = useForm<QuoteFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      customerName: "",
      representativeName: "",
      items: [{ description: "", quantity: 1, price: 0 }],
    }
  })
  
  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "items",
  });

  React.useEffect(() => {
     async function fetchData() {
      const [customersData, usersData] = await Promise.all([
        getCustomers(),
        getUsers(),
      ]);
      setCustomers(customersData);
      setRepresentatives(usersData.filter(u => u.role === 'representative'));
    }
    if (isOpen) {
      fetchData();
      form.reset(defaultValues || {
        customerName: "",
        representativeName: "",
        items: [{ description: "", quantity: 1, price: 0 }],
      })
    }
  }, [isOpen, defaultValues, form])

  const handleSubmit = async (values: QuoteFormValues) => {
    setIsSubmitting(true);
    await onSubmit(values);
    setIsSubmitting(false);
  }

  const dialogTitle = defaultValues ? "Detalhes da Cotação" : "Criar Nova Cotação"
  const dialogDescription = defaultValues ? "Veja ou edite os detalhes da cotação abaixo." : "Preencha os detalhes da nova cotação."
  const buttonText = defaultValues ? "Salvar Alterações" : "Criar Cotação"
  const isReadOnly = !!defaultValues;

  const total = form.watch('items').reduce((acc, item) => acc + (item.quantity || 0) * (item.price || 0), 0);
  const formattedTotal = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(total);

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle className="font-headline">{dialogTitle}</DialogTitle>
          <DialogDescription>{dialogDescription}</DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               <FormField
                  control={form.control}
                  name="customerName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Cliente</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value} disabled={isReadOnly}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione um cliente" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {customers.map(c => (
                            <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                 <FormField
                  control={form.control}
                  name="representativeName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Representante</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value} disabled={isReadOnly}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione um representante" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {representatives.map(rep => (
                            <SelectItem key={rep.id} value={rep.name}>{rep.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
            </div>
            
            <div className="space-y-4">
              <FormLabel>Itens da Cotação</FormLabel>
              {fields.map((field, index) => (
                <div key={field.id} className="flex gap-2 items-end">
                  <FormField
                    control={form.control}
                    name={`items.${index}.description`}
                    render={({ field }) => (
                      <FormItem className="flex-grow">
                        <FormLabel className="sr-only">Descrição</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Descrição do item" readOnly={isReadOnly} />
                        </FormControl>
                         <FormMessage />
                      </FormItem>
                    )}
                  />
                   <FormField
                    control={form.control}
                    name={`items.${index}.quantity`}
                    render={({ field }) => (
                      <FormItem className="w-24">
                        <FormLabel className="sr-only">Qtd.</FormLabel>
                        <FormControl>
                            <Input {...field} type="number" placeholder="Qtd" readOnly={isReadOnly} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                   <FormField
                    control={form.control}
                    name={`items.${index}.price`}
                    render={({ field }) => (
                      <FormItem className="w-32">
                         <FormLabel className="sr-only">Preço Unit.</FormLabel>
                        <FormControl>
                            <Input {...field} type="number" placeholder="Preço" readOnly={isReadOnly} />
                        </FormControl>
                         <FormMessage />
                      </FormItem>
                    )}
                  />
                  {!isReadOnly && (
                    <Button type="button" variant="destructive" size="icon" onClick={() => remove(index)}>
                      <TrashIcon className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
               {!isReadOnly && (
                <Button type="button" variant="outline" size="sm" onClick={() => append({ description: "", quantity: 1, price: 0 })}>
                  Adicionar Item
                </Button>
              )}
            </div>

            <div className="flex justify-end items-center pt-4">
                <span className="text-lg font-semibold">Total: {formattedTotal}</span>
            </div>

             <DialogFooter>
                <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isSubmitting}>Fechar</Button>
                {!isReadOnly && 
                    <Button type="submit" disabled={isSubmitting}>
                        {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {buttonText}
                    </Button>
                }
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
