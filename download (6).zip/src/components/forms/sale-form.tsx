"use client"

import * as React from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Sale, Customer, User } from "@/lib/types"
import { getCustomers } from "@/services/customer-service"
import { getUsers } from "@/services/user-service"
import { Loader2 } from "lucide-react"

const saleStatuses: Sale['status'][] = ['Concluída', 'Pendente', 'Cancelada'];

const formSchema = z.object({
  customerName: z.string().min(1, "Selecione um cliente."),
  product: z.string().min(2, { message: "O nome do produto deve ter pelo menos 2 caracteres." }),
  amount: z.coerce.number().positive({ message: "O valor deve ser positivo." }),
  representativeName: z.string().min(1, { message: "Selecione um representante." }),
  status: z.enum(saleStatuses),
})

export type SaleFormValues = z.infer<typeof formSchema>

type SaleFormProps = {
  isOpen: boolean
  onOpenChange: (isOpen: boolean) => void
  onSubmit: (values: SaleFormValues) => void
  defaultValues?: Sale | null
}

export function SaleForm({ isOpen, onOpenChange, onSubmit, defaultValues }: SaleFormProps) {
  const [customers, setCustomers] = React.useState<Customer[]>([]);
  const [representatives, setRepresentatives] = React.useState<User[]>([]);
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const form = useForm<SaleFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
        customerName: "",
        product: "",
        amount: 0,
        representativeName: "",
        status: "Pendente",
    }
  })

  React.useEffect(() => {
     async function fetchData() {
      const [customersData, usersData] = await Promise.all([
        getCustomers(),
        getUsers(),
      ]);
      setCustomers(customersData);
      setRepresentatives(usersData.filter(u => u.role === 'representative'));
    }
    if (isOpen) {
      fetchData();
      form.reset(defaultValues || {
        customerName: "",
        product: "",
        amount: 0,
        representativeName: "",
        status: "Pendente",
      })
    }
  }, [isOpen, defaultValues, form])

  const handleSubmit = async (values: SaleFormValues) => {
    setIsSubmitting(true);
    await onSubmit(values);
    setIsSubmitting(false);
  }

  const dialogTitle = defaultValues ? "Editar Venda" : "Adicionar Nova Venda"
  const dialogDescription = defaultValues
    ? "Atualize os detalhes da venda abaixo."
    : "Preencha os detalhes da nova venda abaixo."
    
  const buttonText = defaultValues ? "Salvar Alterações" : "Adicionar Venda"

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-headline">{dialogTitle}</DialogTitle>
          <DialogDescription>{dialogDescription}</DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4 py-4">
            <FormField
              control={form.control}
              name="customerName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Cliente</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um cliente" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {customers.map(c => (
                        <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="product"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Produto</FormLabel>
                  <FormControl>
                    <Input placeholder="Ex: Licença de Software" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Valor</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="Ex: 5000" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="representativeName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Representante</FormLabel>
                   <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um representante" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {representatives.map(rep => (
                        <SelectItem key={rep.id} value={rep.name}>{rep.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o status da venda" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {saleStatuses.map(status => (
                        <SelectItem key={status} value={status}>{status}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
             <DialogFooter>
                <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isSubmitting}>Cancelar</Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {buttonText}
                  </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
