"use client"

import * as React from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import type { Company } from "@/lib/types"

const formSchema = z.object({
  name: z.string().min(2, { message: "O nome da empresa deve ter pelo menos 2 caracteres." }),
  industry: z.string().min(2, { message: "O setor deve ter pelo menos 2 caracteres." }),
  contactPerson: z.string().min(2, { message: "O nome do contato deve ter pelo menos 2 caracteres." }),
  contactEmail: z.string().email({ message: "Email de contato inválido." }),
})

export type CompanyFormValues = z.infer<typeof formSchema>

type CompanyFormProps = {
  isOpen: boolean
  onOpenChange: (isOpen: boolean) => void
  onSubmit: (values: CompanyFormValues) => void
  defaultValues?: Company | null
}

export function CompanyForm({ isOpen, onOpenChange, onSubmit, defaultValues }: CompanyFormProps) {
  const form = useForm<CompanyFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
        name: "",
        industry: "",
        contactPerson: "",
        contactEmail: ""
    }
  })

  React.useEffect(() => {
    if (isOpen) {
      form.reset(defaultValues || {
        name: "",
        industry: "",
        contactPerson: "",
        contactEmail: ""
      })
    }
  }, [isOpen, defaultValues, form])

  const dialogTitle = defaultValues ? "Editar Empresa" : "Adicionar Nova Empresa"
  const dialogDescription = defaultValues
    ? "Atualize os detalhes da empresa representada."
    : "Preencha os detalhes da nova empresa representada."
    
  const buttonText = defaultValues ? "Salvar Alterações" : "Adicionar Empresa"

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="font-headline">{dialogTitle}</DialogTitle>
          <DialogDescription>{dialogDescription}</DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nome da Empresa</FormLabel>
                  <FormControl>
                    <Input placeholder="Ex: InnoTech" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="industry"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Setor</FormLabel>
                  <FormControl>
                    <Input placeholder="Ex: Tecnologia" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="contactPerson"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Pessoa de Contato</FormLabel>
                  <FormControl>
                    <Input placeholder="Ex: Mariana Costa" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="contactEmail"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email de Contato</FormLabel>
                  <FormControl>
                    <Input placeholder="Ex: mariana@innotech.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <DialogFooter>
                <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
                <Button type="submit">{buttonText}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}
