import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { recentActivities } from "@/lib/data";
import { Badge } from "@/components/ui/badge";
import { Users, FileText, CalendarCheck, ShoppingCart } from "lucide-react";
import { cn } from "@/lib/utils";


const activityIcons = {
    'adicionou um novo lead': <Users className="h-4 w-4" />,
    'atualizou uma venda para': <ShoppingCart className="h-4 w-4" />,
    'enviou uma cotação para': <FileText className="h-4 w-4" />,
    'agendou um compromisso com': <CalendarCheck className="h-4 w-4" />,
} as const;

export function RecentActivity() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-headline">Atividade Recente</CardTitle>
        <CardDescription>Um registro das ações mais recentes no CRM.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {recentActivities.map((activity) => (
            <div key={activity.id} className="flex items-start">
              <div className={cn("flex h-9 w-9 items-center justify-center rounded-full bg-muted text-muted-foreground")}>
                {activityIcons[activity.action as keyof typeof activityIcons] || <Users className="h-4 w-4" />}
              </div>
              <div className="ml-4 flex-1">
                <p className="text-sm">
                  <span className="font-semibold">{activity.user}</span>{" "}
                  {activity.action}{" "}
                  <span className="font-semibold text-primary">{activity.target}</span>
                  {activity.status && (
                    <Badge variant="secondary" className="ml-2 bg-accent/50 text-accent-foreground">{activity.status}</Badge>
                  )}
                </p>
                <p className="text-xs text-muted-foreground">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
