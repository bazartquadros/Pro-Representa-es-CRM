"use client";

import {
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarGroup,
  SidebarGroupLabel,
} from "@/components/ui/sidebar";
import {
  Users,
  Building,
  FileText,
  Calendar,
  LayoutDashboard,
  ShoppingCart,
  Users2,
  FileBarChart2,
  UserCog,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";

// A mock function to check user role. Replace with your actual auth logic.
const useUserRole = () => ({ role: 'admin' });

export function SidebarNav() {
  const pathname = usePathname();
  const { role } = useUserRole();

  const menuItems = [
    {
      href: "/dashboard",
      icon: <LayoutDashboard />,
      label: "Dashboard",
    },
    {
      href: "/customers",
      icon: <Users />,
      label: "Clientes",
    },
    {
      href: "/sales",
      icon: <ShoppingCart />,
      label: "Vendas",
    },
    {
      href: "/leads",
      icon: <Users2 />,
      label: "Leads",
    },
    {
      href: "/quotes",
      icon: <FileText />,
      label: "Cotações",
    },
    {
      href: "/appointments",
      icon: <Calendar />,
      label: "Compromissos",
    },
    {
      href: "/companies",
      icon: <Building />,
      label: "Representadas",
    },
    {
      href: "/reports",
      icon: <FileBarChart2 />,
      label: "Relatórios",
    },
    ...(role === 'admin' ? [{
      href: "/users",
      icon: <UserCog />,
      label: "Usuários",
      adminOnly: true,
    }] : []),
  ];

  return (
    <SidebarGroup>
      <SidebarGroupLabel className="font-headline">Navegação</SidebarGroupLabel>
      <SidebarMenu>
        {menuItems.map((item) => (
          <SidebarMenuItem key={item.href}>
            <Link href={item.href} passHref>
              <SidebarMenuButton
                asChild
                isActive={pathname === item.href}
                tooltip={item.label}
              >
                <div>
                  {item.icon}
                  <span>{item.label}</span>
                </div>
              </SidebarMenuButton>
            </Link>
          </SidebarMenuItem>
        ))}
      </SidebarMenu>
    </SidebarGroup>
  );
}
