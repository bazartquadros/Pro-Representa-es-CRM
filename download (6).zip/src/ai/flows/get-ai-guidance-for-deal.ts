'use server';
/**
 * @fileOverview An AI agent that provides sales guidance for a specific deal.
 *
 * - getAiGuidanceForDeal - A function that retrieves AI-powered sales suggestions for a deal.
 * - GetAiGuidanceForDealInput - The input type for the getAiGuidanceForDeal function.
 * - GetAiGuidanceForDealOutput - The return type for the getAiGuidanceForDeal function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GetAiGuidanceForDealInputSchema = z.object({
  dealHistory: z.string().describe('O histórico da negociação.'),
  customerDetails: z.string().describe('Detalhes sobre o cliente.'),
});
export type GetAiGuidanceForDealInput = z.infer<typeof GetAiGuidanceForDealInputSchema>;

const GetAiGuidanceForDealOutputSchema = z.object({
  suggestions: z.string().describe('Sugestões geradas por IA para o representante de vendas.'),
});
export type GetAiGuidanceForDealOutput = z.infer<typeof GetAiGuidanceForDealOutputSchema>;

export async function getAiGuidanceForDeal(input: GetAiGuidanceForDealInput): Promise<GetAiGuidanceForDealOutput> {
  return getAiGuidanceForDealFlow(input);
}

const prompt = ai.definePrompt({
  name: 'getAiGuidanceForDealPrompt',
  input: {schema: GetAiGuidanceForDealInputSchema},
  output: {schema: GetAiGuidanceForDealOutputSchema},
  prompt: `Você é um assistente de vendas de IA que fornece orientação a representantes de vendas.

  Com base no histórico da negociação e nos detalhes do cliente, forneça sugestões para orientar o representante de vendas.

  Histórico da Negociação: {{{dealHistory}}}
  Detalhes do Cliente: {{{customerDetails}}}

  Sugestões:`, // Garanta que a resposta se concentre em fornecer conselhos acionáveis
});

const getAiGuidanceForDealFlow = ai.defineFlow(
  {
    name: 'getAiGuidanceForDealFlow',
    inputSchema: GetAiGuidanceForDealInputSchema,
    outputSchema: GetAiGuidanceForDealOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
