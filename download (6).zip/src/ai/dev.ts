import { config } from 'dotenv';
config();

import '@/ai/flows/get-ai-guidance-for-deal.ts';