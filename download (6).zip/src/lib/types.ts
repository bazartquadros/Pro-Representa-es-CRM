export type User = {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'representative';
};

export type Customer = {
  id: string;
  name: string;
  email: string;
  phone: string;
  company: string;
  createdAt: string | { seconds: number, nanoseconds: number };
};

export type CustomerFormValues = Omit<Customer, 'id' | 'createdAt'>;

export type Sale = {
  id: string;
  customerName: string;
  product: string;
  amount: number;
  date: string | { seconds: number, nanoseconds: number };
  representativeName: string;
  status: 'Concluída' | 'Pendente' | 'Cancelada';
};

export type Lead = {
  id:string;
  name: string;
  company: string;
  email: string;
  phone: string;
  status: 'Novo' | 'Contatado' | 'Qualificado' | 'Perdido';
  source: string;
  assignedTo: string;
  createdAt: string | { seconds: number, nanoseconds: number };
};

export type Quote = {
  id: string;
  customerName: string;
  representativeName: string;
  total: number;
  status: 'Enviado' | 'Aceito' | 'Rejeitado';
  createdAt: string | { seconds: number, nanoseconds: number };
  expiresAt: string | { seconds: number, nanoseconds: number };
  items: QuoteItem[];
};

export type QuoteItem = {
  description: string;
  quantity: number;
  price: number;
}

export type Appointment = {
  id: string;
  title: string;
  customerName: string;
  representativeName: string;
  dateTime: string | { seconds: number, nanoseconds: number };
  status: 'Agendado' | 'Realizado' | 'Cancelado';
};

export type Company = {
  id: string;
  name: string;
  industry: string;
  contactPerson: string;
  contactEmail: string;
};
