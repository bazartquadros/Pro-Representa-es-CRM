import { User, Customer, Sale, Lead, Quote, Appointment, Company } from './types';

export const users: User[] = [
  // This data will now be fetched from Firestore
];

export const customers: Customer[] = [
  // This data will now be fetched from Firestore
];

export const sales: Sale[] = [
  // This data will now be fetched from Firestore
];

export const leads: Lead[] = [
  // This data will now be fetched from Firestore
];

export const quotes: Quote[] = [
  // This data will now be fetched from Firestore
];

export const appointments: Appointment[] = [
  // This data will now be fetched from Firestore
];

export const companies: Company[] = [
  // This data will now be fetched from Firestore
];

export const recentActivities = [
  {
    id: 'act-1',
    user: 'Ana Silva',
    action: 'adicionou um novo lead',
    target: 'Construct Co.',
    time: 'Há 2 horas',
  },
  {
    id: 'act-2',
    user: 'Carlos Souza',
    action: 'atualizou uma venda para',
    target: 'Inova Corp',
    status: 'Concluída',
    time: 'Há 5 horas',
  },
  {
    id: 'act-3',
    user: 'Ana Silva',
    action: 'enviou uma cotação para',
    target: 'Retail King',
    time: 'Há 1 dia',
  },
  {
    id: 'act-4',
    user: 'Carlos Souza',
    action: 'agendou um compromisso com',
    target: 'Agro Business Inc.',
    time: 'Há 2 dias',
  },
];
