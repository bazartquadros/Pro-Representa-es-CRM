// Import the functions you need from the SDKs you need
import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCbZ861n7jh7cRsvqNttI4CpV7r4PsgPJI",
  authDomain: "boreal-doodad-473217-e7.firebaseapp.com",
  projectId: "boreal-doodad-473217-e7",
  storageBucket: "boreal-doodad-473217-e7.appspot.com",
  messagingSenderId: "497370653357",
  appId: "1:497370653357:web:a19f129be227fe9e691c24",
  measurementId: "G-TKYL06YN66"
};

// Initialize Firebase
const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export { app, auth, db };
